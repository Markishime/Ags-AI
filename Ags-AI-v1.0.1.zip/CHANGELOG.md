## Changelog

### v1.0.0
- Step 1 Nutrient Gap Analysis severity unified to absolute-gap thresholds
- Sorting: Critical > Low > Balanced, each by magnitude desc
- PDF and UI logic aligned for consistent outputs

